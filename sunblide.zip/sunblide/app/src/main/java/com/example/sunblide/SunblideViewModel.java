package com.example.sunblide;

import android.arch.lifecycle.ViewModel;
import android.os.AsyncTask;

public class SunblideViewModel extends ViewModel {

    public static void upOn(){
        MyAsyncTask task = new MyAsyncTask();
        task.execute(Utility.IP_ADDRESS_KITCHEN_A + "/" + Utility.UP_ON);
    }

    public static void upOff(){
        MyAsyncTask task = new MyAsyncTask();
        task.execute(Utility.IP_ADDRESS_KITCHEN_A + "/" + Utility.UP_OFF);
    }

    private static class MyAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            return Utility.makeOrder(strings[0]);
        }
    }
}
