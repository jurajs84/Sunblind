package com.example.sunblide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import javax.xml.datatype.Duration;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    SunblideViewModel sunblideViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button upBtn = findViewById(R.id.up_btn);
        upBtn.setOnTouchListener(this);

        Button downBtn = findViewById(R.id.down_btn);
        downBtn.setOnTouchListener(this);

        Button upFullBtn = findViewById(R.id.up_full_btn);
        upFullBtn.setOnTouchListener(this);

        Button downFullBtn = findViewById(R.id.down_full_btn);
        downFullBtn.setOnTouchListener(this);

        sunblideViewModel = new SunblideViewModel();

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (v.getId()) {
            case (R.id.up_btn):
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    sunblideViewModel.upOn();
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    sunblideViewModel.upOff();

            }
            break;
            case (R.id.down_btn):
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    sunblideViewModel.upOff();
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    downOff();

            }
            break;
            case (R.id.up_full_btn):
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    upOn();
                }

            break;
            case (R.id.down_full_btn):
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    downOn();
                }

            break;
        }
        return true;
    }

    private void downOff() {
        Toast.makeText(this, "down OFF", Toast.LENGTH_SHORT).show();
    }

    private void downOn() {
        Toast.makeText(this, "down ON", Toast.LENGTH_SHORT).show();
    }

    private void upOff() {
        Toast.makeText(this, "up OFF", Toast.LENGTH_SHORT).show();
    }

    private void upOn() {
        Toast.makeText(this, "up ON", Toast.LENGTH_SHORT).show();
    }
}
